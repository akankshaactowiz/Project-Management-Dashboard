import { useEffect, useState } from "react";
import { Navigate, Outlet } from "react-router-dom";

export default function ProtectedRoute() {
  const [loading, setLoading] = useState(true);
  const [isAuth, setIsAuth] = useState(false);

  useEffect(() => {
    fetch(`http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/auth/profile`, {
      method: "GET",
      credentials: "include", // send cookies
    })
      .then((res) => {
        if (res.ok) {
          setIsAuth(true);
        } else {
          setIsAuth(false);
        }
      })
      .catch(() => setIsAuth(false))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  // ❌ Not authenticated → redirect to login page
  if (!isAuth) {
    return <Navigate to="/" replace />;
  }

  // ✅ Authenticated → render child route
  return <Outlet />;
}
