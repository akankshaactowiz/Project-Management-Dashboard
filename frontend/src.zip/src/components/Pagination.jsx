// components/PaginationControls.jsx
export default function PaginationControls({
  currentPage,
  totalPages,
  onPageChange,
//   pageSize,
//   onPageSizeChange,
}) {
  return (
    <div className="flex items-center justify-end py-2">
      {/* Rows per page */}
      {/* <div className="flex items-center gap-2">
        <span>Show</span>
        <select
          value={pageSize}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
          className="border rounded p-1"
        >
          {[10, 25, 50, 100].map((size) => (
            <option key={size} value={size}>
              {size}
            </option>
          ))}
        </select>
        <span>entries</span>
      </div> */}

      {/* Page navigation */}
     <div className="flex items-center gap-2">
  <button
    onClick={() => onPageChange(Math.max(currentPage - 1, 1))}
    disabled={currentPage === 1}
    className={`px-2 py-1 rounded ${
      currentPage === 1 ? 'bg-gray-200 cursor-not-allowed' : 'bg-purple-700 text-[#fff] cursor-pointer'
    }`}
  >
    Prev
  </button>
  <span>
    Page {currentPage} of {totalPages}
  </span>
  <button
    onClick={() => onPageChange(Math.min(currentPage + 1, totalPages))}
    disabled={currentPage === totalPages}
    className={`px-2 py-1 rounded ${
      currentPage === totalPages ? 'bg-gray-200 cursor-not-allowed' : 'bg-purple-700 text-[#fff] cursor-pointer'
    }`}
  >
    Next
  </button>
</div>

    </div>
  );
}
