// components/CreateTaskModal.jsx
export default function CreateTaskModal({ isOpen, onClose }) {
  if (!isOpen) return null; // don't render if closed

return (
  <div className="fixed inset-0 flex items-center justify-center bg-black/40 z-50 overflow-auto">
    <div className="bg-white w-full max-w-4xl p-6 rounded-2xl shadow-xl relative m  mt-12">
      <h2 className="text-xl font-bold mb-6 text-gray-800">Create New Task</h2>

      {/* Task Details Section */}
      <div className="mb-6">
        <h3 className="mb-4 bg-purple-200 text-purple-700 px-3 py-2 rounded-md text-md font-semibold">
          Task Details
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Task Title</label>
            <input
              type="text"
              placeholder="Task Title"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
            <input
              type="text"
              placeholder="Department"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Related To</label>
            <input
              type="text"
              placeholder="Eg. Project, Ticket, etc."
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Task Type</label>
            <input
              type="text"
              placeholder="Task Type"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Task Priority</label>
            <input
              type="text"
              placeholder="Eg. High, Medium, Low"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Task Status</label>
            <input
              type="text"
              placeholder="Eg. New, In progress, etc."
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Project</label>
            <select className="w-full bg-gray-100 rounded p-2">
              <option value="">Select Project</option>
              <option value="Project A">Project A</option>
              <option value="Project B">Project B</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Select Feed</label>
            <select className="w-full bg-gray-100 rounded p-2">
              <option value="">Select Feed</option>
              <option value="Feed A">Feed A</option>
              <option value="Feed B">Feed B</option>
            </select>
          </div>
        </div>
      </div>

      {/* Additional Information Section */}
      <div className="mb-6">
        <h3 className="mb-4 bg-purple-200 text-purple-700 px-3 py-2 rounded-md text-md font-semibold">
          Additional Information
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Assigned To</label>
            <input
              type="text"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Assigned By</label>
            <input
              type="text"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Estimate Task Start Date
            </label>
            <input
              type="date"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Estimate Task End Date
            </label>
            <input
              type="date"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Add Watcher</label>
            <input
              type="text"
              className="w-full bg-gray-100 rounded p-2"
            />
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end gap-3 pt-4">
        <button
          onClick={onClose}
          className="px-5 py-2 rounded-lg bg-gray-200 text-gray-700 font-medium hover:bg-gray-300 transition"
        >
          Cancel
        </button>
        <button className="px-5 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition">
          Save Task
        </button>
      </div>
    </div>
  </div>
);

}
