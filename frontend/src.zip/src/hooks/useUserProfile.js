import { useState, useEffect } from 'react';

let cachedUser = null;

export function useUserProfile() {
  const [user, setUser] = useState(cachedUser);
  const [loading, setLoading] = useState(!cachedUser);

  useEffect(() => {
    if (!cachedUser) {
      fetch(`http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/auth/profile`, { credentials: 'include' })
        .then(res => {
          if (!res.ok) throw new Error('Failed to fetch profile');
          return res.json();
        })
        .then(data => {
          cachedUser = data;
          setUser(data);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
  }, []);

  return { user, loading };
}
