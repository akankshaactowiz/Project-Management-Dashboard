import { Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "../page/Home.jsx";
import ProtectedRoute from "../components/ProtectedRoute";
import AuthPage from "../page/AuthPage.jsx";
import Escalations from "../page/Escalations.jsx";
import FeedPage from "../page/feed.jsx";
import QA from "../page/QA.jsx";
import Tasks from "../page/Tasks.jsx";
import Work from "../page/Work.jsx";
import Support from "../page/Support.jsx";
import Profile from "../page/Profile.jsx";
import FeedDetails from "../page/FeedDetails.jsx";
import Layout from "../page/Layout.jsx";

function AppRoutes() {
  return (
    <Routes>
      {/* Public route */}
      <Route path="/" element={<AuthPage />} />

      {/* Protected routes with layout */}
      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/home" element={<Dashboard />} />
          <Route path="/feed" element={<FeedPage />} />
          <Route path="/feed/:id" element={<FeedDetails />} />
          <Route path="/escalations" element={<Escalations />} />
          <Route path="/qa" element={<QA />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/work" element={<Work />} />
          <Route path="/support" element={<Support />} />
          <Route path="/profile" element={<Profile />} />
        </Route>
      </Route>

      {/* Catch-all → redirect */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default AppRoutes;
