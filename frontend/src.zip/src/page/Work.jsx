import React, { useState, useEffect } from "react";
import { FaFilePdf, FaFileCsv } from "react-icons/fa6";
import { FaSearch } from "react-icons/fa";
import { RiFileExcel2Fill } from "react-icons/ri";
import { LuFileJson } from "react-icons/lu";
import Breadcrumb from "../components/Breadcrumb";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Pagination from '../components/Pagination'
import flattenObject from "../utils/flattenObject";
import Img from '../assets/no-data-found.svg'
export default function WorkReport() {
 

  const [entries, setEntries] = useState(10);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);

useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/work`);
        if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);

        const rawData = await res.json();

        // Flatten nested objects
        const flattenedData = rawData.map(item => flattenObject(item));
        setData(flattenedData);

        // Collect unique keys as table columns
        const allKeys = new Set();
        flattenedData.forEach(row => {
          Object.keys(row).forEach(k => allKeys.add(k));
        });

        // Remove unwanted Mongo keys
        setColumns(
          [...allKeys].filter(k => !["_id", "__v", "createdAt", "updatedAt"].includes(k))
        );

      } catch (err) {
        console.error("Error fetching escalations:", err);
      }
    };
    fetchData();
  }, []);
  // Filter data by search
  const filteredData = data.filter((item) => {
    const searchLower = search.toLowerCase();
    return (
      item.project.toLowerCase().includes(searchLower) ||
      item.feed.toLowerCase().includes(searchLower) ||
      item.task.toLowerCase().includes(searchLower) ||
      item.date.toLowerCase().includes(searchLower) ||
      item.timeTaken.toLowerCase().includes(searchLower) ||
      item.developer.toLowerCase().includes(searchLower) ||
      item.wfh.toLowerCase().includes(searchLower) ||
      item.report.toLowerCase().includes(searchLower)
    );
  });

  // Pagination calculations
  const totalPages = Math.ceil(filteredData.length / entries) || 1;

  // Reset page if current page exceeds total pages (e.g., when entries or search changes)
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  const paginatedData = filteredData.slice(
    (currentPage - 1) * entries,
    currentPage * entries
  );

  return (
    <>
     
          {/* 90px or enough to clear fixed header + breadcrumb */}
        <div className="flex bg-gray-50 items-center justify-end px-4">
     
      <button
        className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-1 rounded cursor-pointer"
        onClick={() => {
          // Your report viewing logic here
          alert('View Report clicked!');
        }}
      >
        View Report
      </button>
    </div>

          <div className="px-4 pt-4">
            {/* Filters */}
            <div className="bg-gray-50 backdrop-blur-lg p-4 mb-6 border-b border-gray-200">
              <div className="flex justify-between items-start">
                {/* Left - Filters */}
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4 w-full md:w-[90%]">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Project <span className="text-red-500">*</span>
                    </label>
                    <select className="p-2 rounded bg-white/80 w-full">
                      <option>Select Project</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Feed <span className="text-red-500">*</span>
                    </label>
                    <select className="p-2 rounded bg-white/80 w-full">
                      <option>Select Feed</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Task <span className="text-red-500">*</span>
                    </label>
                    <select className="p-2 rounded bg-white/80 w-full">
                      <option>Select Task</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Date
                    </label>
                    <input type="date" className="p-2 rounded bg-white/80 w-full" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Hours
                    </label>
                    <select className="p-2 rounded bg-white/80 w-full">
                      <option>00</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Minutes
                    </label>
                    <select className="p-2 rounded bg-white/80 w-full">
                      <option>00</option>
                    </select>
                  </div>
                </div>

                {/* Right - Button */}
                <div className="mt-6 md:mt-0 md:w-[10%] flex justify-end">
                  <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded shadow">
                    + Add
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-3 gap-4">
              {/* Show entries */}
              <div className="flex items-center space-x-2">
                <label htmlFor="entries" className="text-gray-700 text-sm">
                  Show
                </label>
                <select
                  id="entries"
                  value={entries}
                  onChange={(e) => {
                    setEntries(Number(e.target.value));
                    setCurrentPage(1); // reset page
                  }}
                  className="border border-gray-300 rounded px-2 py-1 text-sm"
                >
                  {[10, 25, 50, 100].map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
                <span className="text-gray-700 text-sm">entries</span>
              </div>

              {/* Search and Export */}
              <div className="flex items-center space-x-3">
                {/* Search */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search..."
                    value={search}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setCurrentPage(1); // reset page
                    }}
                    className="border border-gray-300 rounded pl-8 pr-3 py-1"
                  />
                  <FaSearch className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" />
                </div>

                {/* Export icons */}
                <button
                  title="PDF"
                  className="text-gray-600 hover:text-gray-900"
                  onClick={() => alert("Copy clicked")}
                >
                  <FaFilePdf size={16} className="text-red-700" />
                </button>
                <button
                  title="Excel"
                  className="text-green-600 hover:text-green-800"
                  onClick={() => alert("Excel clicked")}
                >
                  <RiFileExcel2Fill size={16} />
                </button>
                <button
                  title="CSV"
                  className="text-blue-600 hover:text-blue-800"
                  onClick={() => alert("CSV clicked")}
                >
                  <FaFileCsv size={16} />
                </button>
                <button
                  title="JSON"
                  className="text-yellow-500 hover:text-yellow-700"
                  onClick={() => alert("JSON clicked")}
                >
                  <LuFileJson size={16} />
                </button>
              </div>
            </div>

            {/*Table */}
            <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50 text-gray-700">
                            <tr 
                            
                            >
                              {columns.map(col => (
                                <th key={col} className="px-3 py-2 text-left font-semibold whitespace-nowrap">
                                  {col.replace(/\./g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {paginatedData.length > 0 ? (
                              paginatedData.map((row, idx) => (
                                <tr key={idx}
                            
                        onClick={() => console.log("Row clicked:", row)}
                        className={`cursor-pointer transition ${
                          idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                        } hover:text-blue-600`}
                              >
                                  {columns.map(col => (
                                    <td key={col} className="px-3 py-2 whitespace-nowrap">
                                      {row[col] ?? "-"}
                                    </td>
                                  ))}
                                </tr>
                              ))
                            ) : (
                              <tr>
                               <td
                                       colSpan={columns.length}
                                       className="text-center p-8 text-gray-500"
                                     >
                                       <div className="flex flex-col items-center justify-center gap-3">
                                         <img
                                           src={Img}
                                           alt="No data"
                                           className="w-32 h-32 object-contain opacity-80"
                                         />
                                         <p className="font-semibold text-lg text-gray-600">
                                           No Data Found
                                         </p>
                                         <p className="text-sm text-gray-400">
                                           Try adjusting your filters or adding new entries.
                                         </p>
                                       </div>
                                     </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>

            {/* Pagination */}
            <Pagination
                        currentPage={currentPage}
                        totalPages={totalPages}
                        onPageChange={setCurrentPage}
                      />
            
          </div>
        
    </>
  );
}
