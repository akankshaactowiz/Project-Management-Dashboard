import { useState, useEffect } from "react";

import Img from "../assets/profile.svg";
import { useUserProfile } from "../hooks/useUserProfile";
function Home() {
  // State for user profile
  const { user } = useUserProfile();
  // State for tickets data
  const [tickets, setTickets] = useState([]);
  // state for task data
  const [tasks, setTasks] = useState([]);
  // state for feed data
  // const [feeds, setFeeds] = useState([]);
  // state for loading
  const [loading, setLoading] = useState(true);
  // Fetch tickets data
  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const res = await fetch(
          `http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/tickets`
        );
        const data = await res.json();
        setTickets(data);
      } catch (err) {
        console.error("Error fetching tickets:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchTickets();
  }, []);
  // Compute counts
  const totalTickets = tickets.length;
  const unresolvedTickets = tickets.filter(
    (t) => t.status && t.status.toLowerCase() !== "resolved"
  ).length;
  // fetch task data
  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const res = await fetch(
          `http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/tasks`
        );
        const data = await res.json();
        setTasks(data);
      } catch (err) {
        console.error("Error fetching tasks:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchTasks();
  }, []);
  // Compute counts
  const totalTasks = tasks.length;
  // Make sure user exists
  const assignedByMe = tasks.filter((t) => t.assignedBy === user?.name).length;
  const createdByMe = tasks.filter((t) => t.createdBy === user?.name).length;
  const completed = tasks.filter(
    (t) => t.status?.toLowerCase() === "Completed"
  ).length;
  const inProgress = tasks.filter(
    (t) => t.status?.toLowerCase() === "in-progress"
  ).length;
  const terminated = tasks.filter(
    (t) => t.status?.toLowerCase() === "terminated"
  ).length;
  const totalPending = tasks.filter(
    (t) => t.status?.toLowerCase() === "pending"
  ).length;
  const pastPending = tasks.filter((t) => {
    if (!t.dueDate) return false;
    const due = new Date(t.dueDate);
    return t.status?.toLowerCase() === "pending" && due < new Date();
  }).length;
  const taskCounts = [
    { label: "Total Task", count: totalTasks },
    { label: "Assigned by Me", count: assignedByMe },
    { label: "Completed", count: completed },
    { label: "In-progress", count: inProgress },
    { label: "Terminated", count: terminated },
    { label: "Created by Me", count: createdByMe },
    { label: "Total Pending", count: totalPending },
    { label: "Past Pending", count: pastPending },
  ];
  const feedRows = [
    "Total Feed",
    "Blocking Issue",
    "Crawl Yet to Start",
    "Crawl Running",
    "Crawl Finished",
    "Assigned to QA",
    "QA Running",
    "QA Failed",
    "QA Passed",
    "QA Rejected",
    "Delayed",
    "Delivered",
  ];
 return (
    <div className="flex flex-col md:flex-row gap-4">
  {/* Left Profile Section */}
  <aside className="bg-white p-6 rounded-md shadow-md flex flex-col items-center md:w-1/4">
    <img
      src={Img}
      alt="Profile"
      className="w-32 h-32 rounded-full mb-4 object-cover"
    />
    <h2 className="text-xl font-semibold mb-2">{user?.name || "No Name"}</h2>
    <p className="text-gray-600 mb-4">{user?.email || "No Email"}</p>
    <p className="text-center text-gray-700 mb-6 px-2">Software Developer.</p>

    <div className="bg-gray-100 px-5 py-3 rounded-lg shadow-sm w-full text-center">
      <p className="text-sm uppercase tracking-wide font-semibold mb-1">
        Total Projects
      </p>
      <p className="text-3xl font-bold">24</p>
    </div>
  </aside>

  {/* Feed Section */}
  <section className="bg-white p-4 rounded-md shadow-sm overflow-y-auto md:w-2/4">
    <h2 className="text-lg font-semibold mb-4 text-gray-800">Feed Details</h2>
    <div className="overflow-x-auto">
      <table className="min-w-full rounded-md">
        <thead className="bg-gray-100">
          <tr>
            <th className="px-4 py-2 text-left text-gray-600">Feed Status</th>
            <th className="px-4 py-2 text-left text-gray-600">Total</th>
            <th className="px-4 py-2 text-left text-gray-600">Today</th>
            <th className="px-4 py-2 text-left text-gray-600">Tomorrow</th>
          </tr>
        </thead>
        <tbody>
          {feedRows.map((feedName, index) => {
            let textColorClass = "text-gray-900";
            if (feedName === "QA Failed")
              textColorClass = "text-red-600 bg-red-100 font-semibold";
            else if (feedName === "QA Rejected")
              textColorClass = "text-yellow-800 bg-yellow-100 font-semibold";
            else if (feedName === "QA Passed")
              textColorClass = "text-green-600 bg-green-100 font-semibold";
            else if (feedName === "Delayed")
              textColorClass = "text-amber-600 font-semibold";
            else if (feedName === "Delivered")
              textColorClass = "text-teal-600 font-semibold";

            return (
              <tr
                key={index}
                className="hover:bg-gray-50 border-t border-gray-200"
              >
                <td className={`px-4 py-2 ${textColorClass}`}>{feedName}</td>
                <td className={`px-4 py-2 ${textColorClass}`}>0</td>
                <td className={`px-4 py-2 ${textColorClass}`}>0</td>
                <td className={`px-4 py-2 ${textColorClass}`}>0</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  </section>

  {/* Task + Support Column */}
  <section className="flex flex-col gap-4 md:w-1/4">
    {/* Task Overview */}
    <div className="bg-white p-4 rounded-md shadow-sm flex-1">
      <h2 className="text-lg font-semibold mb-4">Task Overview</h2>
      {loading ? (
        <p className="text-gray-500 text-sm">Loading...</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-100">
                <th className="px-4 py-2 text-left text-gray-600 font-medium">
                  Task Type
                </th>
                <th className="px-4 py-2 text-center text-gray-600 font-medium">
                  Count
                </th>
              </tr>
            </thead>
            <tbody>
              {taskCounts.map((task, index) => {
                let textColorClass = "text-gray-700";
                if (task.label === "Total Pending")
                  textColorClass = "text-blue-600 font-semibold bg-blue-100";
                if (task.label === "Past Pending")
                  textColorClass = "text-red-600 font-semibold bg-red-100";

                return (
                  <tr
                    key={index}
                    className="border-t border-gray-200 hover:bg-gray-50 transition"
                  >
                    <td className={`px-4 py-2 ${textColorClass}`}>
                      {task.label}
                    </td>
                    <td
                      className={`px-4 py-2 ${textColorClass} text-center text-gray-900 font-semibold`}
                    >
                      {task.count}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>

    {/* Support Tickets */}
    <div className="bg-white p-4 rounded-md shadow-sm flex-1">
      <h2 className="text-lg font-semibold text-gray-700 mb-4">
        Support Tickets
      </h2>
      {loading ? (
        <p className="text-gray-500 text-sm">Loading...</p>
      ) : (
        <div className="flex justify-around items-center">
          <div className="flex flex-col items-center">
            <span className="text-gray-500 text-sm">Total</span>
            <span className="text-xl font-bold text-blue-600">
              {totalTickets}
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-gray-500 text-sm">Unresolved</span>
            <span className="text-xl font-bold text-red-500">
              {unresolvedTickets}
            </span>
          </div>
        </div>
      )}
    </div>
  </section>
</div>

  );
}
export default Home;