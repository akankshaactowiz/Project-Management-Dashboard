import React, { useState, useEffect } from "react";
import { FaFilePdf, FaFileCsv } from "react-icons/fa6";
import { RiFileExcel2Fill } from "react-icons/ri";
import { LuFileJson } from "react-icons/lu";
import Header from "../components/Header";
import Breadcrumb from "../components/Breadcrumb";
import QADashboard from '../components/QADashboard';
import Footer from "../components/Footer";
import Pagination from "../components/Pagination";
import Img from '../assets/no-data-found.svg';

export default function QA() {
  const [isDashboard, setIsDashboard] = useState(false); // default Feed View
  const [qaData, setQaData] = useState([]);
  const [entries, setEntries] = useState(10);
  const [search, setSearch] = useState("");
  const [active, setActive] = useState("Feed View");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Normalize feedId keys (replace non-breaking spaces)
  const normalizeKeys = (obj) => {
    if (!obj) return {};
    const normalized = {};
    Object.keys(obj).forEach((key) => {
      const newKey = key.replace(/\u00A0/g, " ");
      normalized[newKey] = obj[key];
    });
    return normalized;
  };

  // Fetch QA data from backend
  useEffect(() => {
    const fetchQAData = async () => {
      try {
        const queryParams = new URLSearchParams({
          page: currentPage,
          limit: entries,
          search,
        });

        const res = await fetch(
          `http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/qa?${queryParams}`
        );
        if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);
        const result = await res.json();

        // Normalize feedId keys
        const normalizedData = result.data.map((item) => ({
          ...item,
          feedId: normalizeKeys(item.feedId),
        }));

        setQaData(normalizedData);
        setTotalPages(result.totalPages);

      } catch (err) {
        console.error("Error fetching QA data:", err);
      }
    };

    fetchQAData();
  }, [currentPage, entries, search, isDashboard]);

  return (
    <>
   
            <div className="p-2">
              {/* Toggle Buttons */}
              <div className="inline-flex justify-end w-full">
                <div className="rounded-full border border-purple-800 shadow-md m-2">
                  {["Feed View", "QA Dashboard"].map((label) => (
                    <button
                      key={label}
                      onClick={() => {
                        setActive(label);
                        setIsDashboard(label === "QA Dashboard");
                      }}
                      className={`px-4 py-2 font-medium transition-colors duration-200
                        ${
                          active === label
                            ? "bg-purple-800 text-white"
                            : "text-purple-600"
                        }
                        rounded-full first:rounded-full last:rounded-full
                      `}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Controls: Show entries + Search + Export icons */}
              {isDashboard ? (
                <QADashboard />
              ) : (
                <>
                  <div className="flex flex-col mt-4 md:flex-row md:items-center md:justify-between mb-2 gap-3">
                    {/* Left: Show entries */}
                    <div className="flex items-center space-x-2">
                      <label htmlFor="entries" className="text-gray-700">
                        Show
                      </label>
                      <select
                        id="entries"
                        value={entries}
                        onChange={(e) => {
                          setEntries(Number(e.target.value));
                          setCurrentPage(1); // reset page on change
                        }}
                        className="border rounded px-2 py-1"
                      >
                        {[10, 25, 50, 100].map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                      <span className="text-gray-700">entries</span>
                    </div>

                    {/* Right: Search and export */}
                    <div className="flex items-center space-x-3">
                      {/* Search */}
                      <div className="relative">
                        <input
                          type="text"
                          placeholder="Search..."
                          value={search}
                          onChange={(e) => {
                            setSearch(e.target.value);
                            setCurrentPage(1); // reset page on search
                          }}
                          className="border border-gray-300 rounded pl-8 pr-3 py-1 text-sm"
                        />
                        <svg
                          className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-gray-400"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <circle cx="11" cy="11" r="7" />
                          <line x1="16.5" y1="16.5" x2="21" y2="21" />
                        </svg>
                      </div>

                      {/* Export icons */}
                      <button
                        title="PDF"
                        className="text-gray-600 hover:text-gray-900"
                        onClick={() => alert("PDF Export clicked")}
                      >
                        <FaFilePdf size={16} className="text-red-700" />
                      </button>
                      <button
                        title="Excel"
                        className="text-green-600 hover:text-green-800"
                        onClick={() => alert("Excel Export clicked")}
                      >
                        <RiFileExcel2Fill size={16} className="text-green-600" />
                      </button>
                      <button
                        title="CSV"
                        className="text-blue-600 hover:text-blue-800"
                        onClick={() => alert("CSV Export clicked")}
                      >
                        <FaFileCsv size={16} className="text-blue-600" />
                      </button>
                      <button
                        title="JSON"
                        className="text-yellow-500 hover:text-yellow-700"
                        onClick={() => alert("JSON Export clicked")}
                      >
                        <LuFileJson size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Table */}
                  <div className="max-h-[400px] overflow-x-auto mb-4 border border-gray-50">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr className="text-center">
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">#</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">Feed Name</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">Project Name</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">PM</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">PC</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">Developer</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">QA Error</th>
                          <th className="px-3 py-2 text-left font-semibold whitespace-nowrap">QA Report</th>
                        </tr>
                      </thead>
                      <tbody>
                        {qaData.length > 0 ? (
                          qaData.map((item, idx) => (
                            <tr
                              key={item._id}
                              className={`cursor-pointer transition ${
                                idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                              } hover:text-blue-600`}
                            >
                              <td className="px-3 py-2">{(currentPage - 1) * entries + idx + 1}</td>
                              <td className="px-3 py-2">{item.feedId?.["Feed Name"] || "-"}</td>
                              <td className="px-3 py-2">{item.feedId?.["Project Name"] || "-"}</td>
                              <td>{item.feedId?.["PM"] || "-"}</td>
                              <td>{item.feedId?.["PC"] || "-"}</td>
                              <td>{item.feedId?.["Developer"] || "-"}</td>
                              <td className="px-3 py-2">{item["QA Error"]}</td>
                              <td className="px-3 py-2">{item["QA report"] || "-"}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={8} className="text-center p-8 text-gray-500">
                              <div className="flex flex-col items-center justify-center gap-3">
                                <img
                                  src={Img}
                                  alt="No data"
                                  className="w-32 h-32 object-contain opacity-80"
                                />
                                <p className="font-semibold text-lg text-gray-600">No Data Found</p>
                                <p className="text-sm text-gray-400">
                                  Try adjusting your filters or adding new entries.
                                </p>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pagination */}
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                  />
                </>
              )}
            </div>
      
    </>
  );
}
