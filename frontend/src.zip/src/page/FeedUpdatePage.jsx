import React from 'react'
import Header from '../components/Header'
import Breadcrumb from '../components/Breadcrumb'
function FeedUpdatePage() {
  return (
    <>
    <div className="min-h-screen flex flex-col bg-gray-50">
          <Header />
          <main className="pt-[90px] px-4">
            <Breadcrumb />
          </main>
          </div>

    </>
  )
}

export default FeedUpdatePage