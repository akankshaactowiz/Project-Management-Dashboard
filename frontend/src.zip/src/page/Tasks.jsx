import React, { useState, useEffect } from "react";
import { FaFilePdf, FaFileCsv } from "react-icons/fa6";
import { FaSearch } from "react-icons/fa";
import { RiFileExcel2Fill } from "react-icons/ri";
import { LuFileJson } from "react-icons/lu";

import Header from "../components/Header";
import Breadcrumb from "../components/Breadcrumb";
import Footer from "../components/Footer";
import Pagination from "../components/Pagination";
import Img from "../assets/no-data-found.svg";
import flattenObject from "../utils/flattenObject";
import Model from "../components/CreateTask";

export default function TaskPage() {
  const [activeTab, setActiveTab] = useState("My task");
  const [activeStatus, setActiveStatus] = useState("All");
  const [entries, setEntries] = useState(10);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [taskData, setTaskData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const res = await fetch(
          `http://${import.meta.env.VITE_BACKEND_NETWORK_ID}/api/tasks`
        );

        if (!res.ok) {
          throw new Error(`HTTP error! Status: ${res.status}`);
        }

        const data = await res.json();
        // console.log(data)

        // Flatten the data
        const flattenedData = data.map((item) => flattenObject(item));
        setTaskData(flattenedData);

        // Extract all unique column keys
        const allKeys = new Set();
        flattenedData.forEach((row) => {
          Object.keys(row).forEach((k) => allKeys.add(k));
        });

        // Remove unwanted keys
        setColumns(
          [...allKeys].filter(
            (k) => !["_id", "__v", "createdAt", "updatedAt"].includes(k)
          )
        );
      } catch (err) {
        console.error("Error fetching feed data:", err);
      }
    };

    fetchTasks();
  }, []);

  const tabs = ["My task", "Team task", "Task assigned by me", "My Watcher"];
  const statusTabs = [
    "All",
    "New",
    "In Progress",
    "Complete",
    "Decline",
    "On Hold",
    "Terminated",
    "Recurring",
    "Reopen",
  ];

  // Filter data by search & status
  const filteredData = taskData.filter((task) => {
    const searchLower = search.toLowerCase();
    const matchesSearch =
      task.no?.toLowerCase().includes(searchLower) ||
      task.project?.toLowerCase().includes(searchLower) ||
      task.task?.toLowerCase().includes(searchLower) ||
      task.assignedBy?.toLowerCase().includes(searchLower) ||
      task.assignedTo?.toLowerCase().includes(searchLower) ||
      task.status?.toLowerCase().includes(searchLower);

    const matchesStatus =
      activeStatus === "All" || task.status === activeStatus;

    return matchesSearch && matchesStatus;
  });

  // Total pages for pagination
  const totalPages = Math.ceil(filteredData.length / entries) || 1;

  // Reset current page if out of range
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [entries, filteredData.length, currentPage, totalPages]);

  // Paginate data
  const paginatedData = filteredData.slice(
    (currentPage - 1) * entries,
    currentPage * entries
  );

  return (
    <>
    

          <div className="px-4 pt-2">
            {/* Tabs */}
            <div className="bg-gray-100 px-2 py-2 rounded-md mb-4 flex flex-wrap gap-1 select-none">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-1 rounded font-medium ${
                    activeTab === tab
                      ? "bg-blue-600 text-white"
                      : "bg-gray-300 text-gray-700"
                  }`}
                >
                  {tab}
                </button>
              ))}

              <button className="ml-auto bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded transition"
              onClick={() => setIsModalOpen(true)}
              >
                + Create Task
              </button>
            </div>

            {/* Create Task Model */}
             {isModalOpen && (
          <Model isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      )}

            {/* Status Tabs */}
            <div className="border-b border-gray-200 mb-4 overflow-x-auto whitespace-nowrap">
              {statusTabs.map((status) => (
                <button
                  key={status}
                  onClick={() => setActiveStatus(status)}
                  className={`inline-block px-4 py-2 text-xs font-medium transition-colors duration-200 ${
                    activeStatus === status
                      ? "border-b-2 border-purple-800 text-purple-800"
                      : "text-gray-500"
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            {/* Table Controls */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-3 gap-4">
              {/* Entries per page */}
              <div className="flex items-center space-x-2">
                <label htmlFor="entries" className="text-gray-700 text-sm">
                  Show
                </label>
                <select
                  id="entries"
                  value={entries}
                  onChange={(e) => setEntries(Number(e.target.value))}
                  className="border border-gray-300 rounded px-2 py-1 text-sm"
                >
                  {[10, 25, 50, 100].map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
                <span className="text-gray-700 text-sm">entries</span>
              </div>

              {/* Search & Export */}
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="border border-gray-300 rounded pl-8 pr-3 py-1 text-sm"
                  />
                  <FaSearch className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" />
                </div>

                <button title="PDF">
                  <FaFilePdf size={16} className="text-red-700" />
                </button>
                <button title="Excel">
                  <RiFileExcel2Fill size={16} className="text-green-600" />
                </button>
                <button title="CSV">
                  <FaFileCsv size={16} className="text-blue-600" />
                </button>
                <button title="JSON">
                  <LuFileJson size={16} className="text-yellow-500" />
                </button>
              </div>
            </div>

            {/* Table */}

            <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
              <table
                className="min-w-full divide-y divide-gray-200"
                data={taskData}
              >
                <thead className="bg-gray-50 text-gray-700">
                  <tr>
                    {columns.map((col) => (
                      <th
                        key={col}
                        className="px-3 py-2 text-left font-semibold whitespace-nowrap"
                      >
                        {col
                          .replace(/\./g, " ")
                          .replace(/\b\w/g, (c) => c.toUpperCase())}
                      </th>
                    ))}
                  </tr>
                </thead>
               <tbody>
  {paginatedData.length > 0 ? (
    paginatedData.map((row, idx) => (
      <tr
        key={idx}
        className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}
      >
        {columns.map((col) => {
          const value = row[col] ?? "-";
          return (
            <td key={col} className="px-3 py-2 whitespace-nowrap">
              {col.replace(/\s/g, "") === "status" ? (
                <span
                  className={`inline-flex items-center px-3 py-1 font-medium rounded-full ${
                    value === "Complete"
                      ? "bg-green-100 text-green-700 border border-green-300"
                      : value === "In Progress"
                      ? "bg-yellow-100 text-yellow-700 border border-yellow-300"
                      : "bg-gray-100 text-gray-600 border border-gray-300"
                  }`}
                >
                  {value}
                </span>
              ) : (
                value
              )}
            </td>
          );
        })}
      </tr>
    ))
  ) : (
    <tr>
      <td colSpan={columns.length} className="text-center p-8 text-gray-500">
        <div className="flex flex-col items-center justify-center gap-3">
          <img
            src={Img}
            alt="No data"
            className="w-32 h-32 object-contain opacity-80"
          />
          <p className="font-semibold text-lg text-gray-600">No Data Found</p>
          <p className="text-sm text-gray-400">
            Try adjusting your filters or adding new entries.
          </p>
        </div>
      </td>
    </tr>
  )}
</tbody>

              </table>
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        
    </>
  );
}
